using PGFPlotsX
const def_linewidth = "very thick"
const color_eDMD = "orange"
const color_jDMD = "cyan"
const color_nominal = "black"
lineopts = @pgf {no_marks, "very thick"}